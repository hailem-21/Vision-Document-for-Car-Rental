package edu.mum.cs.cs425.demos.studentrecordsmgmtapp;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import edu.mum.cs.cs425.demos.studentrecordsmgmtapp.model.Student;

public class MyStudentRecordsMgmtApp {
	public static void main(String[] args) {
		Student[] students=new Student[5];
		Student s1= new Student("110001","Dave",LocalDate.parse("1951-11-18"));
		Student s2= new Student("110002","Anna",LocalDate.parse("1990-12-07"));
		Student s3= new Student("110003","Erica",LocalDate.parse("1974-01-31"));
		Student s4= new Student("110004","Carlos",LocalDate.parse("2009-08-22"));
		Student s5= new Student("110005","Bob",LocalDate.parse("1990-03-05"));
				students[0]=s1;students[1]=s2;students[2]=s3;students[3]=s4;students[4]=s5;
				
				
				
				
				printListOfStudents(students);
				Comparator<Student> c=new DateComparator();
				List<Student> pStudents=getListOfPlatinumAlumniStudents(students);
				Collections.sort(pStudents,c );
				System.out.println(pStudents);
				
				
				Integer[] i= {19,9,11,0,12};
				printHelloWorld(i);
				
				System.out.println(findSecondBiggest(i));
				
	}
	public static void printListOfStudents(Student[] st) {
		Arrays.sort(st);
		for(Student s:st) {
			System.out.println(s);
		}
	}
	public static List<Student> getListOfPlatinumAlumniStudents(Student[] st) {
////	
		List<Student> list=new ArrayList<>();
		LocalDate currentDate=LocalDate.now();
		
		for(Student s:st) {
			if(currentDate.getYear()-s.getDate().getYear()>=30) {
				list.add(s);
			}
			
		}
		return list;
		
	}
	public static void printHelloWorld(Integer[] nums) {
		for(Integer i:nums) {
			if(i%5==0&& i%7==0) 
				System.out.println("HelloWorld");
			else if(i%7==0)
				System.out.println("World");
			else if(i%5==0)
				System.out.println("Hello");
		}
		
	}
	public static int findSecondBiggest(Integer[] nums) {
		int max=nums[0];
		int secondMax=nums[1];
		if(max<secondMax) {
			int temp=max;
			max=secondMax;
			secondMax=temp;
		}
		for(Integer i:nums) {
			if(max<i) {
				secondMax=max;
				max=i;
				
			}else if(secondMax<i&& i!=max) {
				secondMax=i;
			}
		}
		
		return secondMax;
		
	}

}
