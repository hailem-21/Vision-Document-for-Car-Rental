package edu.mum.cs.cs425.demos.studentrecordsmgmtapp.model;

import java.time.LocalDate;

public class Student implements Comparable<Student>{
	private String id;
	private String name;
	private LocalDate date;

	@Override
	public String toString() {
		return "Student [id=" + id + ", name=" + name + ", date=" + date + "]";
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public LocalDate getDate() {
		return date;
	}

	public void setDate(LocalDate date) {
		this.date = date;
	}

	public Student(String id, String name, LocalDate date) {
		this.id = id;
		this.name = name;
		this.date = date;

	}

	public Student() {

	}

	public Student(String id, String name) {

		this(id, name, LocalDate.now());
	}

	@Override
	public int compareTo(Student o) {
		
		return this.name.compareTo(o.name);
	}
}
