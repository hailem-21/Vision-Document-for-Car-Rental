package edu.mum.cs.cs425.demos.studentrecordsmgmtapp;

import java.util.Comparator;

import edu.mum.cs.cs425.demos.studentrecordsmgmtapp.model.Student;

public class DateComparator implements Comparator<Student>{

	@Override
	public int compare(Student o1, Student o2) {
		if(o1.compareTo(o2)>1)return -1;
		if(o1.compareTo(o2)<1)return 1;
		return 0;
	}

}
