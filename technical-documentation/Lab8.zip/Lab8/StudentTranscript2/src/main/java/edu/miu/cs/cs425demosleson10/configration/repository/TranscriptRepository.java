package edu.miu.cs.cs425demosleson10.configration.repository;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import edu.miu.cs.cs425demosleson10.configration.model.Transcript;

@Repository
public interface TranscriptRepository extends CrudRepository<Transcript, Long> {

}
