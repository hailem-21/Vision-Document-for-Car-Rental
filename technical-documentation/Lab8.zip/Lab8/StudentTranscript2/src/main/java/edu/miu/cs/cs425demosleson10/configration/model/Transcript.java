package edu.miu.cs.cs425demosleson10.configration.model;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.validation.constraints.NotEmpty;
@Entity
@Table(name="students")
public class Transcript {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long transcriptId;
	
	@Column(name="degreeTitle", nullable = false)
	@NotEmpty(message = "Degree title can't be empty")
	private String degreeTitle;
	
	@OneToOne(mappedBy = "transcript", fetch = FetchType.EAGER,cascade = CascadeType.ALL)
	private Student student;
	
	

	public Transcript() {
		super();
		
	}



	public Transcript(@NotEmpty(message = "Degree title can't be empty") String degreeTitle, Student student) {
		super();
		this.degreeTitle = degreeTitle;
		this.student = student;
	}



	public Long getTranscriptId() {
		return transcriptId;
	}



	public void setTranscriptId(Long transcriptId) {
		this.transcriptId = transcriptId;
	}



	public String getDegreeTitle() {
		return degreeTitle;
	}



	public void setDegreeTitle(String degreeTitle) {
		this.degreeTitle = degreeTitle;
	}



	public Student getStudent() {
		return student;
	}



	public void setStudent(Student student) {
		this.student = student;
	}



	@Override
	public String toString() {
		return "Transcript [transcriptId=" + transcriptId + ", degreeTitle=" + degreeTitle + ", student=" + student
				+ "]";
	}
	
}