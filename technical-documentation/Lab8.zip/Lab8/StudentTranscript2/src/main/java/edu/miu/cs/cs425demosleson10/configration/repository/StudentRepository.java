package edu.miu.cs.cs425demosleson10.configration.repository;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import edu.miu.cs.cs425demosleson10.configration.model.Student;

@Repository
public interface StudentRepository extends CrudRepository<Student, Long>  {

}
 