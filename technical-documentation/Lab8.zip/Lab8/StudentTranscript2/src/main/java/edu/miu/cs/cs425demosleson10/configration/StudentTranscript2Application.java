package edu.miu.cs.cs425demosleson10.configration;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringApplication;

import org.springframework.boot.autoconfigure.SpringBootApplication;
 import edu.miu.cs.cs425demosleson10.configration.repository.ClassroomRepository;
 import edu.miu.cs.cs425demosleson10.configration.repository.StudentRepository;
 import edu.miu.cs.cs425demosleson10.configration.repository.TranscriptRepository;
import edu.miu.cs.cs425demosleson10.configration.model.Classroom;
import edu.miu.cs.cs425demosleson10.configration.model.Student;
import edu.miu.cs.cs425demosleson10.configration.model.Transcript;

@SpringBootApplication
public class StudentTranscript2Application {
    @Autowired
	private ClassroomRepository classroomRepository;
    @Autowired
	private StudentRepository studentRepository;
    @Autowired
	private TranscriptRepository transcriptRepository;

	
	public static void main(String[] args) {
		SpringApplication.run(StudentTranscript2Application.class, args);
	}

public Transcript saveTranscript(Transcript tr) {
		
		return transcriptRepository.save(tr);
	}

	public Student saveStudent(Student std) {
		
		return studentRepository.save(std);
	}
	
	public Classroom saveClassroom(Classroom cr) {
		
		return classroomRepository.save(cr);
	}


	public void run(String... args) throws Exception {
		
		Classroom classroom=new Classroom("McLaughlin building","M105", null);
		List<Classroom> classroomlist= new ArrayList<>();
		classroomlist.add(classroom);
		Transcript transcript= new Transcript("BS Computer Science",null);
	
		Student student=new Student("1234","Mark",null,"Smkith",3.0,LocalDate.now(),transcript,classroomlist);
	
		
		System.out.println(saveStudent(student));
		
		
		student.setClassroomList(classroomlist);
		student.setTranscript(transcript);
		System.out.println(saveClassroom(classroom));
		
		System.out.println(saveStudent(student));
		System.out.println(saveTranscript(transcript));
		
	}
}
