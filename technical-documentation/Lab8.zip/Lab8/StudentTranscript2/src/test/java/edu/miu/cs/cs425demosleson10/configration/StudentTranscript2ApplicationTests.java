package edu.miu.cs.cs425demosleson10.configration;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class StudentTranscript2ApplicationTests {

	@Test
	void contextLoads() {
	}

}
