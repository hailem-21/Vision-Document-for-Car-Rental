package HomeWorkLab10.Lab10Homework;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

public class ArrayFlattnenerTestNull {
	private ArrayFlattener arrayFattner;
	@Before
	public void setUp() throws Exception {
		 this.arrayFattner=new  ArrayFlattener();
	}

	@After
	public void tearDown() throws Exception {
		this.arrayFattner=null;
		
	}

	@Test
	public void test() {
		  int[] acctual=arrayFattner.flattenArray(null);
	       int[] expected=null;
	       
	       assertArrayEquals(acctual, expected);
		
		
	}

}
