package HomeWorkLab10.Lab10Homework;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

public class ArrayFlattnenerTest {
	
	private ArrayFlattener arrayFattner;

	@Before
	public void setUp() throws Exception {
		this.arrayFattner=new ArrayFlattener();
	}

	@After
	public void tearDown() throws Exception {
		this.arrayFattner=null;
	}

	@Test
	public void testFlattenArray() {
       int[] acctual=arrayFattner.flattenArray(new int[][] {{1,3},{0},{4,5,9}});
       int[] expected=new int[] {1,3,0,4,5,9};
       
       assertArrayEquals(acctual, expected);

	}

}
