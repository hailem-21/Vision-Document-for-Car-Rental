package HomeWorkLab10.Lab10Homework2;

import static org.junit.Assert.*;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import HomeWorkLab10.Lab10Homework2.service.ArrayFlattenerService;

public class ArrayReversorTestNull {
	private ArrayReversor arrayReversor;
	private ArrayFlattenerService arrayFlattnerService=mock(ArrayFlattenerService.class);

	@Before
	public void setUp() throws Exception {
		this.arrayReversor=new ArrayReversor(arrayFlattnerService);
	}

	@After
	public void tearDown() throws Exception {
		this.arrayFlattnerService=null;
	}

	@Test
	public void test() {
		when(arrayFlattnerService.flattenArray((new int[][] {{1,3},{0},{4,5,9}})))
		 .thenReturn(null);
		 int[] actual = arrayReversor.reverseArray(null);
	       
		 int[] expected = null;
		 
		 assertArrayEquals(actual, expected);
	
		
	}

}
