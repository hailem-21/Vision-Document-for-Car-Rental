package HomeWorkLab10.Lab10Homework;

import java.util.Arrays;

public class ArrayFlattener {
	

	public int[] flattenArray(int[][] arr) {
		
		if(arr==null)return null;
		
		int count=0;
		
		for(int[] i:arr) {
			count+=i.length;
			
			
		}
		
		int[] arr2= new int[count];
		int index=0;
		
		for(int[] i:arr) {
			for(int j:i) {
				arr2[index++]=j;
			}
			
			
		}
		
   return arr2;
		
		
	}

}
