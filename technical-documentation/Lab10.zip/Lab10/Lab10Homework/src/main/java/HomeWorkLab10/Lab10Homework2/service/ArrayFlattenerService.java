package HomeWorkLab10.Lab10Homework2.service;

public interface ArrayFlattenerService {
	
	int [] flattenArray(int[][] arr);

}
