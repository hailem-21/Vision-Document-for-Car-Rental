package HomeWorkLab10.Lab10Homework2;

import java.util.Arrays;

import HomeWorkLab10.Lab10Homework2.service.ArrayFlattenerService;

public class ArrayReversor {
	 private ArrayFlattenerService arrayFlattenerService;

	    public ArrayReversor(ArrayFlattenerService arrayFlattenerService) {
	        this.arrayFlattenerService = arrayFlattenerService;
	    }
	
	public  int[] reverseArray(int[][] arr) {
	 if(arr==null)return null;
		
		int count=0;
		

		for(int i=arr.length-1;i>=0; i--) {
			for(int j=arr[i].length-1;j>=0;j--) {
				count++;
			}
		}
		
		int[] arr2= new int[count];
		int index=0;
		
		for(int i=arr.length-1;i>=0; i--) {
			for(int j=arr[i].length-1;j>=0;j--) {
				arr2[index++]=arr[i][j];
			}
		}
			
		
		return arr2;
			}
			
			
	

}
