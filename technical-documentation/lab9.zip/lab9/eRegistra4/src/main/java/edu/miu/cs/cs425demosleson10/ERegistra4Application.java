package edu.miu.cs.cs425demosleson10;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ERegistra4Application {

	public static void main(String[] args) {
		SpringApplication.run(ERegistra4Application.class, args);
	}

}
