package edu.miu.cs.cs425demosleson10.service;

import java.util.List;
import java.util.Optional;

import edu.miu.cs.cs425demosleson10.model.Student;

public interface StudentService {
	List<Student> getAllStudents();
	
	Student addStudent(Student s);
	
	Student getStudentById(Long studentId);
     void deleteStudentById(Long studentId);
     List<Student> searchStudents(String searchString);
}
