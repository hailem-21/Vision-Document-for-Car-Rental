package edu.miu.cs.cs425demosleson10.service.serviceimpl;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import edu.miu.cs.cs425demosleson10.model.Student;
import edu.miu.cs.cs425demosleson10.repository.StudentRepository;
import edu.miu.cs.cs425demosleson10.service.StudentService;
@Service
public class StudentServiceImpl implements StudentService {
	
	
	@Autowired
	public StudentRepository studentRepository;

	@Override
	public List<Student> getAllStudents() {
		
		return (List<Student>) studentRepository.findAll();
	}

	@Override
	public Student addStudent(Student s) {
		
		return studentRepository.save(s);
	}

	@Override
	public Student getStudentById(Long studentId) {
		
	return studentRepository.findById(studentId).orElse(null);
			
	}

	@Override
	public void deleteStudentById(Long studentId) {
		
		studentRepository.deleteById(studentId);
		
		
	}

	

	@Override
	public List<Student> searchStudents(String searchString) {
		
		return studentRepository.findByStudentNumber(searchString);
	}

}
