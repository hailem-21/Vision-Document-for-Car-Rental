package edu.miu.cs.cs425demosleson10.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class HomeController {
	
	@GetMapping(value= {"/","/eRegistrar","/eRegistrar/home"})
	public String showHomePage() {
		
		return "home/index";
	}
	@GetMapping(value= {"/about","/eRegistrar/about","/eRegistrar/home/about"})
	public String showAboutPage() {
		
		return "about/about";
	}
	
	

}
