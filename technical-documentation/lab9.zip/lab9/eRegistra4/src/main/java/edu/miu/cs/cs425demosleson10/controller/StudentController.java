package edu.miu.cs.cs425demosleson10.controller;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import edu.miu.cs.cs425demosleson10.model.Student;
import edu.miu.cs.cs425demosleson10.service.StudentService;

@Controller
public class StudentController {
	@Autowired
	private StudentService studentService;
	
	
	public StudentController(StudentService studentService) {
		this.studentService=studentService;
	}
	
	
	@GetMapping(value= {"/studentList","/eRegistrar/studentList","/eRegistrar/about/studentList"})
	public ModelAndView displayAllStudents() {
		List<Student> studntList=studentService.getAllStudents();
		ModelAndView modelAndView= new ModelAndView();
		
		modelAndView.addObject("students", studntList);
		modelAndView.addObject("studentsCount", studntList.size());
		modelAndView.setViewName("student/studentList");
		
		return modelAndView;
	}
	
	
	
	
		@GetMapping(value="eRegistrar/student/addStudent")
		public String showAddStudentPage(Model model) {
			Student newStudent =new Student();
			model.addAttribute("student",newStudent);
			
			
			return "student/addStudent";
		}
		
		  @PostMapping(value="/eRegistrar/student/addStudent")
		  public String addNewStudent(@Valid@ModelAttribute("student") Student student,BindingResult bindingResult
				  ,Model model) {
			 if(bindingResult.hasErrors()) {
				 model.addAttribute("errors",bindingResult.getAllErrors());
					return "student/addStudent";
			 }
			  //System.out.println(student);
			  studentService.addStudent(student);
			  
			  return "redirect:/eRegistrar/studentList";
			  
		  }
			
		
		@GetMapping(value="/eRegistrar/student/editStudent/{studentId}")
		public String showEditStudentPage(@PathVariable Long studentId, Model model) {
			Student student = studentService.getStudentById(studentId);
	        if (student != null) {
	            model.addAttribute("student", student);
	            return "student/editStudent";
	        }
	       
			return "student/addStudent";
		}
		
		  @PostMapping(value = {"/eRegistrar/student/editStudent"})
		    public String updateBook(@Valid @ModelAttribute("student") Student student,
		                                BindingResult bindingResult, Model model) {
		        if (bindingResult.hasErrors()) {
		            model.addAttribute("errors", bindingResult.getAllErrors());
		            return "student/editStudent";
		        }
		      studentService.addStudent(student);
		        return "redirect:/eRegistrar/about/studentList";
		    }
		
		
	

  @GetMapping(value = {"/eRegistrar/student/delete/{studentId}"})
  public String deleteBook(@PathVariable Long studentId, Model model) {
	  studentService.deleteStudentById(studentId);

      return "redirect:/eRegistrar/studentList";
  }

	
  @GetMapping(value = {"/eRegistrar/student/search", "/student/search"})
  public ModelAndView searchBooks(@RequestParam String searchString) {
      ModelAndView modelAndView = new ModelAndView();
      List<Student> students = studentService.searchStudents(searchString);
      modelAndView.addObject("students", students);
      modelAndView.addObject("searchString", searchString);
      modelAndView.addObject("studentsCount", students.size());
      modelAndView.setViewName("student/searchStudent");
      return modelAndView;
  }

}
