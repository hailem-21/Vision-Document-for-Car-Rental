package edu.miu.cs.cs425demosleson10.model;

import java.time.LocalDate;
//import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;

import org.springframework.format.annotation.DateTimeFormat;

@Entity
public class Student {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long studentId;
	
    @Column(nullable=false,unique=true)
	@NotBlank(message = "student number required")
	private String studentNumber;
    
    @Column(nullable=false)
	@NotBlank(message = "student firstName required")
	private String firstName;

    
    @Column(nullable=true)
	private String middleName;
    
    @Column(nullable=false)
	@NotBlank(message = "student LastName required")
	private String LastName;
    
    @Column(nullable=true)
	private double cgpa;

    @Column(nullable=false)
	@NotNull(message = "student enrollment date is required")
    @DateTimeFormat(pattern = "yyyy-MM-dd")
	private LocalDate enrollmentDate;
    
    

    @Column(nullable=false)
	
	//@NotBlank(message="student status is required")
	private String isInternational;
	
	public Student(@NotBlank(message = "student number required") String studentNumber,
			@NotBlank(message = "student number required") String firstName, String middleName,
			@NotBlank(message = "student number required") String lastName, double cgpa,
			@NotNull(message = "student enrollment date is required")LocalDate enrollmentDate,
			@NotBlank(message = "student status is required") String isInternational) {

		this.studentNumber = studentNumber;
		this.firstName = firstName;
		this.middleName = middleName;
		LastName = lastName;
		this.cgpa = cgpa;
		this.enrollmentDate = enrollmentDate;
		this.isInternational = isInternational;
	}
	public Student() {}
	public Long getStudentId() {
		return studentId;
	}

	public void setStudentId(Long studentId) {
		this.studentId = studentId;
	}

	public String getStudentNumber() {
		return studentNumber;
	}

	public void setStudentNumber(String studentNumber) {
		this.studentNumber = studentNumber;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getMiddleName() {
		return middleName;
	}

	public void setMiddleName(String middleName) {
		this.middleName = middleName;
	}

	public String getLastName() {
		return LastName;
	}

	public void setLastName(String lastName) {
		LastName = lastName;
	}

	public double getCgpa() {
		return cgpa;
	}

	public void setCgpa(double cgpa) {
		this.cgpa = cgpa;
	}

	public LocalDate getEnrollmentDate() {
		return enrollmentDate;
	}

	public void setEnrollmentDate(LocalDate enrollmentDate) {
		this.enrollmentDate = enrollmentDate;
	}


	public String getIsInternational() {
		return isInternational;
	}
	public void setIsInternational(String isInternational) {
		this.isInternational = isInternational;
	}
	@Override
	public String toString() {
		return "Student [studentId=" + studentId + ", studentNumber=" + studentNumber + ", firstName=" + firstName
				+ ", middleName=" + middleName + ", LastName=" + LastName + ", cgpa=" + cgpa + ", enrollmentDate="
				+ enrollmentDate + ", isInternational=" + isInternational + "]";
	}

	

}
