package edu.miu.cs.cs425demosleson10;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ERegistra4ApplicationTests {

	@Test
	void contextLoads() {
	}

}
