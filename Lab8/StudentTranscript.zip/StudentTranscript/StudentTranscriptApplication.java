package edu.mum.cs.cs425.studentmgmt.StudentTranscript;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.jdbc.DataSourceAutoConfiguration;

import edu.mum.cs.cs425.studentmgmt.StudentTranscript.model.Classroom;
import edu.mum.cs.cs425.studentmgmt.StudentTranscript.model.Student;
import edu.mum.cs.cs425.studentmgmt.StudentTranscript.model.Transcript;
import edu.mum.cs.cs425.studentmgmt.StudentTranscript.repository.ClassroomRepository;
import edu.mum.cs.cs425.studentmgmt.StudentTranscript.repository.StudentRepository;
import edu.mum.cs.cs425.studentmgmt.StudentTranscript.repository.TranscriptRepository;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

@SpringBootApplication
public class StudentTranscriptApplication implements CommandLineRunner{
	
	@Autowired
	private StudentRepository studentRepo;
	@Autowired
	private ClassroomRepository classroomRepository;
	@Autowired
	private TranscriptRepository transcriptRepository;

	public static void main(String[] args) {
		SpringApplication.run(StudentTranscriptApplication.class, args);
		
	}
	
	public Transcript saveTranscript(Transcript tr) {
		
		return transcriptRepository.save(tr);
	}

	public Student saveStudent(Student std) {
		
		return studentRepo.save(std);
	}
	
	public Classroom saveClassroom(Classroom cr) {
		
		return classroomRepository.save(cr);
	}

	@Override
	public void run(String... args) throws Exception {
		Student std = new Student("000-61-0001","Anna","Smith",3.55,LocalDate.now());
		Transcript trs = new Transcript("BS Computer Science");
		saveTranscript(trs);
		std.setTranscript(transcriptRepository.findById(1L).get());
		
		Classroom cr1 = new Classroom("McLaughlin building", "M105");
		cr1.addStudent(std);
		
//		
		saveClassroom(cr1);
		
		saveStudent(std);
		
	}
}
