package edu.mum.cs.cs425.studentmgmt.StudentTranscript.model;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToMany;
import javax.persistence.OneToOne;

import org.springframework.format.annotation.DateTimeFormat;

import com.fasterxml.jackson.annotation.JsonIgnore;

@Entity
public class Student {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private Long studentId;
	
	private String studentNumber;
	private String firstName;
	private String lastName;
	private double cgpa;
	
	@DateTimeFormat(pattern = "yyyy-mm-dd")
	private LocalDate dateOfEnrollement;
	
	@OneToOne()
	private Transcript transcript;
	
	@ManyToMany(mappedBy = "students")
	private List<Classroom> classrooms = new ArrayList<>();
	
	public Student() {}

	@JsonIgnore
	public List<Classroom> getClassrooms() {
		return classrooms;
	}

	public void setClassrooms(List<Classroom> classrooms) {
		this.classrooms = classrooms;
	}

	public Transcript getTranscript() {
		return transcript;
	}
	
//	public void addClassRoom(Classroom c) {
//		this.classrooms.add(c);
//	}

	public void setTranscript(Transcript transcript) {
		this.transcript = transcript;
	}

	public Student(String studentNumber, String firstName, String lastName, double cgpa, LocalDate dateOfEnrollement) {
	
		this.studentNumber = studentNumber;
		this.firstName = firstName;
		this.lastName = lastName;
		this.cgpa = cgpa;
		this.dateOfEnrollement = dateOfEnrollement;
	}

	public Long getStudentId() {
		return studentId;
	}

	public void setStudentId(Long studentId) {
		this.studentId = studentId;
	}

	public String getStudentNumber() {
		return studentNumber;
	}

	public void setStudentNumber(String studentNumber) {
		this.studentNumber = studentNumber;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public double getCgpa() {
		return cgpa;
	}

	public void setCgpa(double cgpa) {
		this.cgpa = cgpa;
	}

	public LocalDate getDateOfEnrollement() {
		return dateOfEnrollement;
	}

	public void setDateOfEnrollement(LocalDate dateOfEnrollement) {
		this.dateOfEnrollement = dateOfEnrollement;
	}

	@Override
	public String toString() {
		return "Student [studentId="+ ", studentNumber=" + studentNumber + ", firstName=" + firstName
				+ ", lastName=" + lastName + ", cgpa=" + cgpa + ", dateOfEnrollement=" + dateOfEnrollement + "]";
	}
	
	
	
	
}
