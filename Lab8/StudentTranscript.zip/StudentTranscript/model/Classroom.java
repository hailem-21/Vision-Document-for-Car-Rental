package edu.mum.cs.cs425.studentmgmt.StudentTranscript.model;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;

import com.fasterxml.jackson.annotation.JsonIgnore;

@Entity
public class Classroom {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private Long classroomId;
	private String buildingName;
	private String roomNumber;
	
	@ManyToMany(cascade = {CascadeType.ALL})
	@JoinTable(
			name = "std_classroom",
			joinColumns = { @JoinColumn( name="fk_classroom") },
			inverseJoinColumns = { @JoinColumn(name = "fk_std")}
			)
	private List<Student> students = new ArrayList<>(); 
	
	public Classroom() {}

	public Classroom( String buildingName, String roomNumber) {
		
		this.buildingName = buildingName;
		this.roomNumber = roomNumber;
	}

	public void addStudent(Student s) {
		this.students.add(s);
		s.getClassrooms().add(this);
	}

	public Long getClassroomId() {
		return classroomId;
	}

	public void setClassroomId(Long classroomId) {
		this.classroomId = classroomId;
	}

	public String getBuildingName() {
		return buildingName;
	}

	public void setBuildingName(String buildingName) {
		this.buildingName = buildingName;
	}

	public String getRoomNumber() {
		return roomNumber;
	}

	public void setRoomNumber(String roomNumber) {
		this.roomNumber = roomNumber;
	}

	@JsonIgnore
	public List<Student> getStudents() {
		return students;
	}

	public void setStudents(List<Student> students) {
		this.students = students;
	}
	
}
