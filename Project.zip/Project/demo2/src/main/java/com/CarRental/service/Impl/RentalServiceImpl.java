package com.CarRental.service.Impl;

import com.CarRental.model.Car;
import com.CarRental.model.Rental;
import com.CarRental.model.RentalStatus;
import com.CarRental.model.User;
import com.CarRental.repository.ICarRepository;
import com.CarRental.repository.IRentalRepository;
import com.CarRental.repository.IUserRepository;
import com.CarRental.service.IRentalService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.transaction.Transactional;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

@Service
@Transactional
public class RentalServiceImpl implements IRentalService {


    @Autowired
    private IRentalRepository rentalRepository;
    @Autowired
    private IUserRepository userRepository;
    @Autowired
    private ICarRepository carRepository;

    @Override
    public void toRentCar(long userId, long carId, LocalDate startingdate, LocalDate returnDate) {
        System.out.println(userId+" "+carId+" "+startingdate);
        User user = userRepository.getOne(userId);                   
        if (user == null) {
            System.out.println("the user is not return, create account");return;
        }
        Car car = carRepository.getOne(carId);                         
        if (car == null) {
            System.out.println("the car already rented");return;
        }
        if (!car.isAvailable()) {
            System.out.println("The car is already been rent out.");return;
        }
        Rental reservedCar= rentalRepository.findByCarAndUserAndStatus(car,user,RentalStatus.RESERVED);
        Rental rental = new Rental();                                     
        rental.setUser(user);
        rental.setCar(car);

        if(startingdate == null) {
            rental.setStartingdate(LocalDate.now());
            rental.setStatus(RentalStatus.RENTED);
            car.setAvailable(false);
        }else {
            rental.setStartingdate(startingdate);
            rental.setStatus(RentalStatus.RENTED);
        }
        System.out.println(rental);
        rentalRepository.save(rental);                                  
    }

    @Override
    public void takeReservedCar(long userId, long carId) throws Exception {
        User user = userRepository.getOne(userId);                     
        if (user == null) {
            throw new Exception("the user is not return, create account");
        }
        Car car = carRepository.getOne(carId);                        
        if (car == null) {
            throw new Exception("the car already rented");
        }
        Rental reservedCar= rentalRepository.findByCarAndUserAndStatus(car,user,RentalStatus.RESERVED);
        Rental rentedCar= rentalRepository.findByCarAndUserAndStatus(car,user,RentalStatus.RENTED);
        if(reservedCar == null && rentedCar != null){
            throw new Exception("there car is no reserved or not Returend yet ");
        }
        reservedCar.setStatus(RentalStatus.RENTED);
        car.setAvailable(false);
        rentalRepository.save(reservedCar);
    }

    @Override
    public User toCheckCustomer(long userid) throws Exception {
        User customer = userRepository.getOne(userid);
        if (customer == null) {
            throw new Exception("create account");
        }
        Rental rental = rentalRepository.findFirstByUserAndEnddayIsNull(customer);
        if (rental == null) {
            throw new Exception("the customer is free");
        } else {
            return customer;
        }
    }

    @Override
    public Car returnCar(long carid) throws Exception {
        Car returnedCar = carRepository.getOne(carid);                    //call from cat database
        if (returnedCar == null) {
            throw new Exception("the car is not rented or it is not available");
        } else {
            Rental rental = rentalRepository.findFirstByCarAndEnddayIsNull(returnedCar);   
            if (rental == null) {
                throw new Exception("the car is not rented");
            }
            rental.setEndday(LocalDate.now());                             
            rental.setStatus(RentalStatus.RETURNED);                        
            returnedCar.setAvailable(true);                               
    }
        return returnedCar;
    }

    @Override
    public List<Car> findByStatus(RentalStatus status) throws Exception {
        List<Rental> rentalList = rentalRepository.findByStatus(status);
        List<Car> carList = new ArrayList<>();

        if (rentalList == null){
            throw new Exception("there is no rented car");
        }
        for (Rental r: rentalList){
            carList.add(r.getCar());
        }
        return carList;
    }

}
