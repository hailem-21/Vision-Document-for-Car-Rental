package com.CarRental.controller;

import com.CarRental.model.Car;
import com.CarRental.model.User;
import com.CarRental.service.ICarService;
import com.CarRental.service.IRentalService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import javax.servlet.http.HttpServletResponse;
import javax.validation.Valid;
import java.time.LocalDate;


@Controller
public class CarController {

    @Autowired
    private ICarService carService;
    @Autowired
    private IRentalService rentalService;

    @GetMapping("/list")
    public String list(Model model){
        model.addAttribute("cars", carService.allCars());
        return "/car/allCars";
    }

    @GetMapping("/list-cust/{uid}")
    public String custList(Model model, @PathVariable Long uid){

        model.addAttribute("uid", uid);
        model.addAttribute("cars", carService.allCars());

        return "/car/allCarsToCust";
    }

    @GetMapping("/add")
    public String getAddForm(Model  model){
        model.addAttribute("car",new Car());
        return "/car/addCarForm";
    }

    @PostMapping("/add")
    public String save(@Valid @ModelAttribute("car") Car car,
                       BindingResult result, Model model){

//        if (result.hasErrors()) {
//            model.addAttribute("errors", result.getAllErrors());
//            System.out.println(result.getAllErrors().toString());
//            return "car/addCarForm";
//        }

        carService.create(car);

        return "redirect:/list";
    }

    @GetMapping("/delete")
    public String delete(@RequestParam("id") Long id) {

        carService.deleteCar(id);

        return "redirect:/list";

    }

    @GetMapping("/update")
    public String getEdit(@RequestParam("id") Long id, Model model){
        model.addAttribute("car",carService.getCar(id));
        return "/car/editCarForm";
    }

    @PostMapping("/update")
    public String edit(@Valid @ModelAttribute("car") Car car){
        carService.create(car);
        return "redirect:/list";
    }


    @GetMapping("/rent")
    public  String rent(@RequestParam("id") Long id, @RequestParam("uid") Long uid){
        System.out.println(id+" 1111111  "+uid);
        rentalService.toRentCar(uid, id, LocalDate.now(),null);
        return "redirect:/";
    }


}
