package com.CarRental.controller;

import com.CarRental.model.Car;
import com.CarRental.model.ERole;
import com.CarRental.model.User;
import com.CarRental.service.IUserServise;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

@Controller
public class UserController {

	@Autowired
	private IUserServise userServise;

	@GetMapping("/signUp")
	public String getSignUpForm(Model model) {
		model.addAttribute("user", new User());
		return "/user/signUp.html";
	}

	@PostMapping("/signUp")
	public String save(@Valid @ModelAttribute("user") User user, BindingResult result, Model model) {

		try {
			userServise.signUp(user);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return "redirect:/signIn";
	}

	@GetMapping("/signIn")
	public String getSignInForm(Model model) {
		model.addAttribute("user", new User());
		return "/user/signIn.html";
	}

	@PostMapping("/signIn")
	public String signIn(@Valid @ModelAttribute("user") User user, BindingResult result, Model model) {
		System.out.println("here");
		try {
			user=userServise.loggIn(user);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		if (user.getWho_R_U().equals(ERole.CUSTOMER)){
			return "redirect:/list-cust/"+user.getId();
		}else {
			return "redirect:/list";
		}

	}
}
