package com.CarRental.model;

public enum RentalStatus {
    RESERVED,RENTED,RETURNED
}
