package com.CarRental.model;

public enum ERole {
    ADMIN,CUSTOMER
}
